from .eagle import eagle, Task


def main():
    eagle()
